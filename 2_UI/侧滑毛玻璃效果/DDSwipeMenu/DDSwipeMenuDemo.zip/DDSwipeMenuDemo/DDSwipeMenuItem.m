//
//  DDSwipeMenuItem.m
//  DDSwipeMenuDemo
//
//  Created by lovelydd on 14-6-20.
//  Copyright (c) 2014年 lovelydd. All rights reserved.
//

#import "DDSwipeMenuItem.h"

@implementation DDSwipeMenuItem

-(id)initWithTitle:(NSString *)title image:(UIImage *)image complete:(CompleteBlock)completeBlock
{
    self = [super init];

    if (self) {
        
        self.title = title;
        self.completeBlock = completeBlock;
        self.imageView = [[UIImageView alloc] initWithImage:image];
        self.imageView.frame = (CGRect){0,0,40,40};


    }
    return self;
}
@end
