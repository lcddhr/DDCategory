//
//  BottomView.h
//  DDSwipeMenuDemo
//
//  Created by lovelydd on 14-6-20.
//  Copyright (c) 2014年 lovelydd. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol BottomViewDelegate <NSObject>

@optional
-(void)bottomViewAction;

@end
@interface BottomView : UIView

@property(nonatomic,assign)id<BottomViewDelegate> delegate;

-(id)initWithTitle:(NSString *)title;

-(void)showBottomView;
-(void)hideBottomView;

@end
