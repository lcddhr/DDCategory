//
//  ViewController.m
//  DDSwipeMenuDemo
//
//  Created by lovelydd on 14-6-20.
//  Copyright (c) 2014年 lovelydd. All rights reserved.
//

#import "ViewController.h"
#import "DDSwipeMenu.h"
#import "FirstViewController.h"

@interface ViewController ()<DDSwipeMenuDelegate>


@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    

    

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}



-(void)DDSwipeMenu:(DDSwipeMenu *)menu didSelectItemAtIndex:(NSInteger)index {
    NSLog(@"Item Cliecked : %ld", (long)index);
    
    [menu hideMenu];
    
    FirstViewController *testVC = [[FirstViewController alloc] init];
    [self.navigationController pushViewController:testVC animated:YES];
}

-(void)DDSwipeMenu:(DDSwipeMenu *)menu selectedItemTitle:(NSString *)title{
//    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Menu Clicked"
//                                                   message:[NSString stringWithFormat:@"Item Title : %@", title]
//                                                  delegate:self
//                                         cancelButtonTitle:@"Dismiss"
//                                         otherButtonTitles:nil, nil];
//    [alert show];
}

@end
