//
//  FirstViewController.h
//  DDSwipeMenuDemo
//
//  Created by lovelydd on 14-6-20.
//  Copyright (c) 2014年 lovelydd. All rights reserved.
//

#import "BaseViewController.h"

@interface FirstViewController : BaseViewController


@property(nonatomic,retain) UIImageView *bgView;
@end
