//
//  BaseViewController.h
//  DDSwipeMenuDemo
//
//  Created by lovelydd on 14-6-20.
//  Copyright (c) 2014年 lovelydd. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "DDSwipeMenu.h"


@interface BaseViewController : UIViewController

//@property(nonatomic,retain) UIImageView *bgView;
//
//@property(nonatomic, assign) id <DDSwipeMenuDelegate> delegate;

-(void)hideOrShowNavigationBar:(BOOL)isHide;

//添加滑动手势返回
-(void)addRightSwipe;
-(void)popToBeforeViewController;
@end
