//
//  BottomView.m
//  DDSwipeMenuDemo
//
//  Created by lovelydd on 14-6-20.
//  Copyright (c) 2014年 lovelydd. All rights reserved.
//

#import "BottomView.h"

#define BOTTOMVIEW_WIDTH  320
#define BOTTOMVIEW_HEIGHT 60
@implementation BottomView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


-(id)initWithTitle:(NSString *)title
{
    
    self = [super init];
    if (self) {
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = (CGRect){100,20,100,40};
        [button addTarget:self action:@selector(buttonAction) forControlEvents:UIControlEventTouchUpInside];
        [button setTitle:title forState:UIControlStateNormal];
        [button setTintColor:[UIColor blackColor]];
        [self addSubview:button];
        
        self.backgroundColor = [UIColor redColor];
    }
    return self;
}

-(void)buttonAction
{
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(bottomViewAction)]) {
        
        [self.delegate bottomViewAction];
    }
    
}

-(void)showBottomView
{
    [UIView animateWithDuration:0.5 animations:^{
        self.frame = (CGRect){0, SCREEN_HEIGHT-BOTTOMVIEW_HEIGHT, BOTTOMVIEW_WIDTH, BOTTOMVIEW_HEIGHT};
    }];
    
}
-(void)hideBottomView
{
    
        [UIView animateWithDuration:0.5 animations:^{
            self.frame = (CGRect){0, SCREEN_HEIGHT+BOTTOMVIEW_HEIGHT, BOTTOMVIEW_WIDTH, BOTTOMVIEW_HEIGHT};
        }];
}



@end
