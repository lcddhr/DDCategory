//
//  BaseViewController.m
//  DDSwipeMenuDemo
//
//  Created by lovelydd on 14-6-20.
//  Copyright (c) 2014年 lovelydd. All rights reserved.
//

#import "BaseViewController.h"


@interface BaseViewController ()


//@property(nonatomic)DDSwipeMenu *sideMenu;
@end

@implementation BaseViewController



-(void)hideOrShowNavigationBar:(BOOL)isHide
{
    
    if (isHide) {
         self.navigationController.navigationBarHidden = YES;
    }
    else
    {
         self.navigationController.navigationBarHidden = NO;
    }
}
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
//    self.title = @"Simple Side Menu";
//   
//    bgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"backGround.jpg"]];
//    bgView.frame = [UIScreen mainScreen].bounds;
//    [self.view addSubview:bgView];
//    
//    
//    UIImageView *author = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"author.png"]];
//    author.frame = CGRectMake(120, 30, 95, 95);
//    author.alpha = 0.4;
//    [self.view addSubview:author];
//    author.layer.borderColor = [UIColor whiteColor].CGColor;
//    author.layer.borderWidth = 3;
//    author.clipsToBounds = YES;
//    author.layer.cornerRadius =  author.frame.size.width/2;
//    
//    
//    
//    DDSwipeMenuItem *item1 = [[DDSwipeMenuItem alloc] initWithTitle:@"One" image:[UIImage imageNamed:@"icon1.png"] complete:^(DDSwipeMenuItem *item) {
//        NSLog(@"The first one");
//    }];
//    
//    
//    DDSwipeMenuItem *item2 = [[DDSwipeMenuItem alloc] initWithTitle:@"second" image:[UIImage imageNamed:@"icon2.png"] complete:^(DDSwipeMenuItem *item) {
//        NSLog(@"The first second");
//    }];
//    
//    DDSwipeMenuItem *item3 = [[DDSwipeMenuItem alloc] initWithTitle:@"third" image:[UIImage imageNamed:@"icon3.png"] complete:^(DDSwipeMenuItem *item) {
//        NSLog(@"The first third");
//    }];
//    
//    sideMenu = [[DDSwipeMenu alloc] initWithItem:@[item1,item2,item3] addToViewController:self];
  
}

//-(void)viewDidAppear:(BOOL)animated
//{
//    [super viewDidAppear:YES];
//    sideMenu.delegate = self.delegate;
//}
#pragma mark Swipe Right
-(void)addRightSwipe
{
    UISwipeGestureRecognizer *swipeGesRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(popToBeforeViewController)];
    swipeGesRight.direction = UISwipeGestureRecognizerDirectionRight;
    [self.view addGestureRecognizer:swipeGesRight];
    
}
-(void)popToBeforeViewController
{
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}


@end
