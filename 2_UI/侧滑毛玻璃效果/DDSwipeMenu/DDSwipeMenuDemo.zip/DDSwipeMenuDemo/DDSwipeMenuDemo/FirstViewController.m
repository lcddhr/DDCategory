//
//  FirstViewController.m
//  DDSwipeMenuDemo
//
//  Created by lovelydd on 14-6-20.
//  Copyright (c) 2014年 lovelydd. All rights reserved.
//

#import "FirstViewController.h"
#import "SecondViewController.h"
#import "DDSwipeMenu.h"
#import "DDSwipeMenuItem.h"

@interface FirstViewController ()<DDSwipeMenuDelegate>
{
    DDSwipeMenuItem *item1;
    DDSwipeMenuItem *item2;
    DDSwipeMenuItem *item3;
    DDSwipeMenuItem *item4;
    UIImageView *author;
}

@property(nonatomic)DDSwipeMenu *sideMenu;
@end

@implementation FirstViewController
@synthesize sideMenu, bgView;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    [self hideOrShowNavigationBar:YES];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    self.title = @"Simple Side Menu";
    [self initView];
   
}

-(void)initView
{

 
    bgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"wuzhishiBG.jpg"]];
    bgView.frame = [UIScreen mainScreen].bounds;
    [self.view addSubview:bgView];
    
    
//    author = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"author.png"]];
//    author.frame = CGRectMake(120, 30, 95, 95);
//    author.alpha = 0.4;
//    [self.view addSubview:author];
//    author.layer.borderColor = [UIColor whiteColor].CGColor;
//    author.layer.borderWidth = 3;
//    author.clipsToBounds = YES;
//    author.layer.cornerRadius =  author.frame.size.width/2;
    
    item1 = [[DDSwipeMenuItem alloc] initWithTitle:@"五指石" image:[UIImage imageNamed:@"icon1.png"] complete:^(DDSwipeMenuItem *item) {
        NSLog(@"The first one");
        
        SecondViewController *secondVC = [[SecondViewController alloc] init];
        [self.navigationController pushViewController:secondVC animated:YES];
    }];
    
    
    item2 = [[DDSwipeMenuItem alloc] initWithTitle:@"南台山卧佛" image:[UIImage imageNamed:@"icon2.png"] complete:^(DDSwipeMenuItem *item) {
        NSLog(@"The first second");
    }];
    
    item3 = [[DDSwipeMenuItem alloc] initWithTitle:@"特色美食" image:[UIImage imageNamed:@"icon3.png"] complete:^(DDSwipeMenuItem *item) {
        NSLog(@"The first third");
    }];
    
    item4 = [[DDSwipeMenuItem alloc] initWithTitle:@"制作人" image:[UIImage imageNamed:@"icon3.png"] complete:^(DDSwipeMenuItem *item) {
        NSLog(@"The first third");
    }];
    
    sideMenu = [[DDSwipeMenu alloc] initWithItem:@[item1,item2,item3,item4] addToViewController:self];
    sideMenu.delegate = self;
}



-(void)DDSwipeMenu:(DDSwipeMenu *)menu didSelectItemAtIndex:(NSInteger)index {
    NSLog(@"Item Cliecked : %ld", (long)index);
    [menu hideMenu];
}

-(void)DDSwipeMenu:(DDSwipeMenu *)menu selectedItemTitle:(NSString *)title{

    
}


@end
