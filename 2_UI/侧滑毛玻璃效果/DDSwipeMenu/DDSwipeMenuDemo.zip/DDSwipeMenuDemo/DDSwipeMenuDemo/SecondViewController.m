//
//  SecondViewController.m
//  DDSwipeMenuDemo
//
//  Created by lovelydd on 14-6-20.
//  Copyright (c) 2014年 lovelydd. All rights reserved.
//

#import "SecondViewController.h"
#import "BottomView.h"

@interface SecondViewController ()<UIScrollViewDelegate,BottomViewDelegate>
{
    
    BottomView *bottomView;
}

@end

static float historyY = 0;
@implementation SecondViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    [self hideOrShowNavigationBar:YES];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //添加手势返回
    [self addRightSwipe];
    
    [self initView];
    
}
-(void)initView
{
    self.view.backgroundColor = [UIColor grayColor];
    UIScrollView *scrollViews = [[UIScrollView alloc] init];
    scrollViews.frame = (CGRect){0,20,SCREEN_WIDTH,SCREEN_HEIGHT-20};
    scrollViews.showsVerticalScrollIndicator = NO;
    scrollViews.backgroundColor = [UIColor clearColor];
    scrollViews.delegate = self;
    [self.view addSubview:scrollViews];
    
    
    UIImageView *bgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"wuzhishi_1_meitu_1.png"]];
    bgView.frame = (CGRect){10,0,300,200};
    [scrollViews addSubview:bgView];
    
    UILabel *textLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    textLabel.frame = (CGRect){bgView.frame.origin.x,bgView.frame.origin.y+5,300,100};
    textLabel.text = @"     五指石风景名胜区,位于粤、赣、闽三省交界的广东省平远县城以北57公里的差干镇内,为粤东著名的丹霞地貌旅游胜地。规划面积16.8平方公里。汇聚了“丹霞地貌、森林生态、人文古迹”三大景观,兼具雄、险、奇、秀、幽、古的特色。1992年被国家旅游局确定为“国家级自然序数旅游景观”之一;1999年被广东省旅游局确定为“省级旅游景区”;同年3月被广东省人民政府批准为“省级风景名胜区”;2000年9月被省旅游局确定为“广东省休闲度假好去处”。景区距206国道28公里;距梅州市区88公里;距江西寻乌县53公里、福建武平县33公里。\n\n      五指石主要由形似五指的宝鼎石(拇指)、罗汉石(食指)、天竺石(中指)、降龙石(无名指)和宝盖石(末指)组成。它们与地面的相对高差均在250米以上，实为红层盆地中心。五指石丹霞地貌的红层基本为水平层理。由于垂直节理发育，在长期强烈的流水侵蚀和重力崩塌作用下，形成了山体陡峭、穿缝发达、岩深洞幽、雄浑隽秀的典型丹霞地貌景观。又因植被覆盖茂密，更使石峰显出外俊内秀的美色。\n\n       五指最高峰海拔460多米。五指石拥有丰富独特的自然和人文景观资源。景区内拥有“五奇”(奇石、奇藤、奇缝、奇树、奇洞)、“八景“(剑门、石林寺、聪明泉、混元塔、一线天、仙人床、隆武殿、青云路）和淡静居、蝴蝶谷、生态乐园等胜景60多处。五指石具有丰富的野生动物植物资源，高等植物70科200余属1000多种，野生动物30多种。五指石属亚热带季风性气候，春天不冷、夏天不热、秋天不燥、冬天不寒，旅游季节较长，奇山异景，林密泉清，故有“灵秀甲天下，差干小桂林”之美喻。原国家文化部副部长吕志先畅游五指石后，题词赞曰：“五指美景人间仙境”，是南粤大地新兴的旅游佳境。";
    textLabel.autoResize = YES;
    textLabel.frame =(CGRect){bgView.frame.origin.x,bgView.frame.origin.y+bgView.frame.size.height,300,textLabel.frame.size.height};
    scrollViews.contentSize = (CGSize){SCREEN_WIDTH,bgView.frame.size.height+textLabel.frame.size.height+5};
    [scrollViews addSubview:textLabel];
    
    bottomView = [[BottomView alloc] initWithTitle:@"查看更多"];
    bottomView.frame = CGRectMake(0, SCREEN_HEIGHT-60, SCREEN_WIDTH, 60);
    bottomView.delegate = self;
    [self.view insertSubview:bottomView aboveSubview:scrollViews];
}

#pragma mark - Button Action
-(void)bottomViewAction
{
    
    NSLog(@"查看更多");
}


#pragma mark - UIScrollview Delegate
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    historyY = scrollView.contentOffset.y;
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView {
    NSLog(@"contentOffSet:%f,    history:%f",scrollView.contentOffset.y,historyY);
    
    if (scrollView.contentOffset.y<historyY) {
        NSLog(@"down");
        [bottomView showBottomView];
    } else if (scrollView.contentOffset.y>historyY) {
        NSLog(@"up");
        [bottomView hideBottomView];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
