//
//  UIView+Screenshot.h
//  DDSwipeMenuDemo
//
//  Created by lovelydd on 14-6-20.
//  Copyright (c) 2014年 lovelydd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Screenshot)
-(UIImage *)screenshot:(CGSize)size;
@end
