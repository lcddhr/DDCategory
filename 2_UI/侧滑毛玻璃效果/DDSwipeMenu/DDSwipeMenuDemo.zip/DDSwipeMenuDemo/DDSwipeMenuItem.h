//
//  DDSwipeMenuItem.h
//  DDSwipeMenuDemo
//
//  Created by lovelydd on 14-6-20.
//  Copyright (c) 2014年 lovelydd. All rights reserved.
//

#import <Foundation/Foundation.h>

@class DDSwipeMenuItem;
typedef void(^CompleteBlock)(DDSwipeMenuItem *item);

@interface DDSwipeMenuItem : NSObject

@property(nonatomic,copy)NSString *title;
@property(nonatomic,strong)UIImageView *imageView;
@property(nonatomic,copy)CompleteBlock completeBlock;

-(id)initWithTitle:(NSString *)title image:(UIImage *)image complete:(CompleteBlock)completeBlock;

@end
