//
//  DDDropMenu.h
//  DDDropViewDemo
//
//  Created by 4399 on 14-9-30.
//  Copyright (c) 2014年 4399. All rights reserved.
//

#import <UIKit/UIKit.h>



@class DDIndexPath;
@class DDDropMenu;
@protocol DDDropMenuDataSource <NSObject>

- (NSInteger)menu:(DDDropMenu *)menu numberOfRowsInColumn:(NSInteger)column;


- (NSString *)menu:(DDDropMenu *)menu titleForRowAtIndexPath:(DDIndexPath *)indexPath;

- (NSInteger)numberOfColumnsInMenu:(DDDropMenu *)menu;

@end

@protocol DDDropmenuDelegate <NSObject>

@required
- (CGFloat)menu:(DDDropMenu *)menu heightForRowAtIndexPath:(DDIndexPath *)indexPath;

- (void)menu:(DDDropMenu *)menu didSelectRowAtIndexPath:(DDIndexPath *)indexPath;

@end


@interface DDDropMenu : UIView<UITableViewDataSource,UITableViewDelegate>


@property(nonatomic, weak)id<DDDropmenuDelegate> delegate;
@property(nonatomic, weak)id<DDDropMenuDataSource> dataSource;

- (instancetype)initWithFrame:(CGRect)frame
           DDDropmenuDelegate:(id<DDDropmenuDelegate>)delegate
         DDDropMenuDataSource:(id<DDDropMenuDataSource>)dataSource;

@end




@interface DDIndexPath : NSObject

@property(nonatomic,assign)NSInteger column;
@property(nonatomic,assign)NSInteger row;

- (instancetype)initWithColumn:(NSInteger)column row:(NSInteger)row;

+ (instancetype)indexPathWithColum:(NSInteger)col row:(NSInteger)row;

@end