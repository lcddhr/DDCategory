//
//  AppDelegate.h
//  DDDropViewDemo
//
//  Created by 4399 on 14-9-30.
//  Copyright (c) 2014年 4399. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
