//
//  DropViewController.m
//  DDDropViewDemo
//
//  Created by 4399 on 14-9-30.
//  Copyright (c) 2014年 4399. All rights reserved.
//


#import "DropViewController.h"
#import "DDDropMenu.h"


@interface DropViewController ()<DDDropMenuDataSource,DDDropmenuDelegate>

@property(nonatomic,strong)NSArray *names;
@property(nonatomic,strong)NSArray *citys;
@property(nonatomic,strong)NSArray *phones;



@end

@implementation DropViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.names  = @[@"name",@"def",@"ghi",@"jkl"];
    self.citys = @[@"citys",@"shenzheng",@"beijing",@"shanghai"];
    self.phones = @[@"phones",@"iPhone",@"sanxing",@"xiaomi"];
    
    DDDropMenu *dropMenu = [[DDDropMenu alloc] initWithFrame:CGRectMake(0, 64, 320, 40) DDDropmenuDelegate:self DDDropMenuDataSource:self];
    [self.view addSubview:dropMenu];
}


#pragma mark DDDropMenuDataSource
- (NSInteger)menu:(DDDropMenu *)menu numberOfRowsInColumn:(NSInteger)column
{
    
    return 3;
}


- (NSInteger)numberOfColumnsInMenu:(DDDropMenu *)menu
{
    
    return 3;
}

- (NSString *)menu:(DDDropMenu *)menu titleForRowAtIndexPath:(DDIndexPath *)indexPath
{
    
    switch (indexPath.column) {
        case 0:
            return self.names[indexPath.row];
            break;
        case 1:
            return self.citys[indexPath.row];
            break;
        case 2:
            return self.phones[indexPath.row];
            break;
        default:
            return nil;
            break;
    }
    
    
}

- (void)menu:(DDDropMenu *)menu didSelectRowAtIndexPath:(DDIndexPath *)indexPath
{
    
    
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
